#!/bin/sh
cobc -x -free test11.cbl
# Fails copy file not found
cobc -x -free test12.cbl
cobc -x -free test13.cbl
cobc -x -fixed test14.cbl
cobc -x -fixed test15.cbl
cobc -x -fixed test16.cbl
cobc -x -fixed test17.cbl
cobc -x -free test18.cbl
cobc -x -free test19.cbl
chmod +x test1*
echo -e "should produce OK"
./test12 
echo -e "\nProduce OK"
./test13
echo -e "\nProduce OKOK"
./test14
echo -e "\nProduce OKOK"
./test15
echo -e "\nProduce OKOK"
./test16
echo -e "\nProduce OK"
./test17
echo -e "\nProduce OK"
./test18
echo -e "\nProduce OK"
./test19
echo -e " \nCheck results against expected"

exit 0
