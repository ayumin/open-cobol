#!/bin/sh
./printcbl test1.cbl test1.prn free HP
# one error msg 1 file not found
./printcbl test2.cbl test2.prn free HP
./printcbl test3.cbl test3.prn -free HP
./printcbl test4.cbl test4.prn fixed HP
./printcbl test5.cbl test5.prn -fixed HP
./printcbl test6.cbl test6.prn fixed HP
./printcbl test7.cbl test7.prn fixed HP
./printcbl test8.cbl test8.prn free HP
./printcbl test9.cbl test9.prn free HP
./printcbl test11.cbl test11.prn free hp
./printcbl test12.cbl test12.prn free HP
./printcbl test13.cbl test13.prn -free HP
./printcbl test14.cbl test14.prn fixed HP
./printcbl test15.cbl test15.prn -fixed HP
./printcbl test16.cbl test16.prn fixed HP
./printcbl test17.cbl test17.prn fixed HP
./printcbl test18.cbl test18.prn free HP
./printcbl test19.cbl test19.prn free HP
cobc -x -free test11.prn
# Fails copy file not found
cobc -x -free test12.prn
cobc -x -free test13.prn
cobc -x -fixed test14.prn
cobc -x -fixed test15.prn
cobc -x -fixed test16.prn
cobc -x -fixed test17.prn
cobc -x -free test18.prn
cobc -x -free test19.prn
chmod +x test1*
echo -e "\nshould produce OK"
./test12 
echo -e "\nProduce OK"
./test13
echo -e "\nProduce OKOK"
./test14
echo -e "\nProduce OKOK"
./test15
echo -e "\nProduce OKOK"
./test16
echo -e "\nProduce OK"
./test17
echo -e "\nProduce OK"
./test18
echo -e "\nProduce OK"
./test19
echo -e "\n Check results against expected"

exit 0
